$(function () {
  new fullpage("#fullpage", {
    scrollingSpeed: 1500,
  });
});
